G�n�rateur al�atoire de CSP

nbVar
tailleMaxDomain     {1,���.,n} (tout prendre puis supprimer)
Contraintes : produit cart�sien des domaines
nbDeCouples par contraintes (ou pourcentage)
Tout prendre puis supprimer !  
1/4	1	..	..	..	N
1					
..					
..					
..					
N					

Densit� : %, nbrTotalContrainte/nbrTouteContraintesPossibles
Duret� : % nbrAutoris�/nbrTotal (couple dans une contrainte) : 0% m�ga dur, 100% tous les couples sont autoris�s
Connectivit� : nbr max de contrainte sur une variable donn�e (min 0, max n-1)

Class  
variable  
contrainte  
CSP  